## xarm7_moveit_config

 	xarm7 moveit configurations

### Unit test

> roslaunch xarm7_moveit_config demo.launch



